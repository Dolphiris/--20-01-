namespace WinForm_CourseW
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton9_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public int ind = 0;

        private void button1_Click(object sender, EventArgs e)
        {
            int errorcounter = 0;
            if (radioButton1.Checked != true && radioButton2.Checked != true && radioButton3.Checked != true)
            {
                MessageBox.Show ("�������� ��� ���������");
                errorcounter++;
            }
            if (radioButton4.Checked != true && radioButton5.Checked != true && radioButton6.Checked != true)
            {
                MessageBox.Show("�������� �������� ��������");
                errorcounter++;
            }
            if (radioButton7.Checked != true && radioButton8.Checked != true && radioButton9.Checked != true && radioButton10.Checked != true)
            {
                MessageBox.Show("�������� ��� ����");
                errorcounter++;
            }

            if(textBox1.Text == "")
            {
                MessageBox.Show("�������� ����� ������� ���������");
                errorcounter++;
            }
            if (textBox2.Text == "")
            {
                MessageBox.Show("�������� ��������");
                errorcounter++;
            }
            if (textBox3.Text == "")
            {
                MessageBox.Show("�������� �������� ������� ����������� �������");
                errorcounter++;
            }

            if (errorcounter > 0) 
                return;

            int z1 = Convert.ToInt32(textBox1.Text);
            int n = Convert.ToInt32(textBox2.Text); 
            int sop = Convert.ToInt32(textBox3.Text);

            double py, ky, kv, kd, kz, k_t, km, kt, n1, tz, t, pys, yz, feu, fi, ni, tzi, k;


            if (radioButton6.Checked == true)
            { 
                if (radioButton1.Checked == true)
                    kd = 1;
                else if (radioButton2.Checked == true)
                    kd = 1;
                else
                    kd = 1.2;
            }
            else if (radioButton5.Checked == true)
            {
                if (radioButton1.Checked == true)
                    kd = 1.2;
                else if (radioButton2.Checked == true)
                    kd = 1.3;
                else 
                    kd = 1.4;
            }
            else 
            {
                if (radioButton1.Checked == true)
                    kd = 1.4;
                else if (radioButton2.Checked == true)
                    kd = 1.5;
                else 
                    kd = 1.7;
            }

            if (radioButton9.Checked == true)
                km = 1;
            else if (radioButton8.Checked == true)
                km = 1.7;
            else if (radioButton7.Checked == true)
                km = 2.5;
            else 
                km = 3;

            tzi = Convert.ToDouble(textBox4.Text);
            n1 = 600;
            tz = 40;
            ni = Convert.ToDouble(textBox5.Text);
            fi = Convert.ToDouble(textBox6.Text);

            ky = 10 * Math.Pow(n1 / 10.0, 1.0 / 9.0);
            kv = Math.Pow((n1/10.0)* (n1 / 10.0), 1.0/3.0);
            double mostof = kv;
            if (ky > kv)
                mostof = ky;
            t = 30.5 * Math.Pow(n * mostof / (n1 * km), 1.0 / 3.0);

            if (t <= 25.4) 
                k = 24; 
            else 
                k = 6;

            feu = Math.Pow(Math.Pow(fi, 4) * (tzi / tz) * Math.Pow(ni / n1, 4.0 / 9.0), 1.0 / 4.0);
            kz = Math.Pow(z1, 1.0 / 12);
            kt = Math.Pow(15000.0/tz, 1.0 / 4.0);
            k_t = Math.Pow(t / 25.4, 1.0 / k);
            pys = 270 * kz * kt / (ky * k_t);
            py = feu * kd / (sop / km);
            dataGridView1.Rows.Add();
            dataGridView1.Rows[ind].Cells[0].Value = Convert.ToString(ind+1);
            dataGridView1.Rows[ind].Cells[1].Value = Convert.ToString(py);
            dataGridView1.Rows[ind].Cells[2].Value = Convert.ToString(ky);
            dataGridView1.Rows[ind].Cells[3].Value = Convert.ToString(kv);
            dataGridView1.Rows[ind].Cells[4].Value = Convert.ToString(kd);
            dataGridView1.Rows[ind].Cells[5].Value = Convert.ToString(kz);
            dataGridView1.Rows[ind].Cells[6].Value = Convert.ToString(k_t);
            dataGridView1.Rows[ind].Cells[7].Value = Convert.ToString(km);
            dataGridView1.Rows[ind].Cells[8].Value = Convert.ToString(kt);
            dataGridView1.Rows[ind].Cells[9].Value = Convert.ToString(z1);
            dataGridView1.Rows[ind].Cells[10].Value = Convert.ToString(n1);
            dataGridView1.Rows[ind].Cells[11].Value = Convert.ToString(tz);
            dataGridView1.Rows[ind].Cells[12].Value = Convert.ToString(n);
            dataGridView1.Rows[ind].Cells[13].Value = Convert.ToString(t);
            dataGridView1.Rows[ind].Cells[14].Value = Convert.ToString(pys);
            dataGridView1.Rows[ind].Cells[15].Value = Convert.ToString(sop);
            dataGridView1.Rows[ind].Cells[16].Value = Convert.ToString(feu);
            dataGridView1.Rows[ind].Cells[17].Value = Convert.ToString(fi);
            dataGridView1.Rows[ind].Cells[18].Value = Convert.ToString(ni);
            dataGridView1.Rows[ind].Cells[19].Value = Convert.ToString(tzi);
            dataGridView1.Rows[ind].Cells[20].Value = Convert.ToString(k);
            ind++;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            radioButton4.Checked = false;
            radioButton5.Checked = false;
            radioButton6.Checked = false;
            radioButton7.Checked = false;
            radioButton8.Checked = false;
            radioButton9.Checked = false;
            radioButton10.Checked = false;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}